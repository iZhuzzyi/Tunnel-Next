#spectrumf
#tif16
#逆傅里叶变换恢复图像
#00FF00
import numpy as np
import cv2

def process(inputs, params):
    if 'spectrumf' not in inputs or inputs['spectrumf'] is None:
        return {'tif16': None}
    
    spectrum = inputs['spectrumf']
    img = np.fft.ifft2(np.fft.ifftshift(spectrum))  # 逆移位并执行逆FFT
    img = np.abs(img.real)  # 取实数部分并确保非负
    
    # 归一化到原始范围并转换为uint16
    img_normalized = cv2.normalize(img, None, 0, 65535, cv2.NORM_MINMAX)
    return {'tif16': img_normalized.astype(np.uint16)}

def get_params():
    return {}  # 无额外参数