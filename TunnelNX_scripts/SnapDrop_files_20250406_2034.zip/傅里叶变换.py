#tif16
#spectrumf
#傅里叶变换生成频谱
#0000FF
import numpy as np
import cv2

def process(inputs, params):
    if 'tif16' not in inputs or inputs['tif16'] is None:
        return {'spectrumf': None}
    
    img = inputs['tif16'].astype(np.float64)  # 转换为高精度浮点数
    spectrum = np.fft.fftshift(np.fft.fft2(img))  # 执行FFT并移位
    return {'spectrumf': spectrum}  # spectrumf 类型为复数数组(np.complex128)

def get_params():
    return {}  # 无额外参数